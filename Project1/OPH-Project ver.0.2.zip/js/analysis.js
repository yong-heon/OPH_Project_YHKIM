
function showSpanContent(radio) {
    var spanContent = radio.nextElementSibling.innerHTML;
    var resultElement = document.querySelector(".result");
    resultElement.innerHTML = spanContent;
}