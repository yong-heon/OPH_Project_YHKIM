// map sidebar 버튼 클릭 이벤트
const infoSidebar = document.querySelector(".informationbar__sidebar");
const sidebar = document.querySelector(".sidebar");
const sidebarBtn = document.querySelector(".sidebar__toggle");

const toggleSidebar = () => {
    infoSidebar.classList.toggle("active");
    sidebar.classList.toggle("active");
};

infoSidebar.addEventListener("click", toggleSidebar);
sidebarBtn.addEventListener("click", toggleSidebar);