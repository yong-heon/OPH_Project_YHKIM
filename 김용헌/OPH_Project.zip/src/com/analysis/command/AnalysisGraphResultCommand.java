package com.analysis.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.analysis.model.*;

public class AnalysisGraphResultCommand implements ACommand {
	 public void execute(HttpServletRequest request, HttpServletResponse response) {
	        String district = request.getParameter("district");
	        String aItem = request.getParameter("aItem");
	        String[] columns = {"salePriceAvg", "jeonsePriceAvg", "monthlyDepositAvg", "monthlyAvg"};

	        ADao dao = new ADao();

	        ArrayList<ArrayList<Double>> avgValues = new ArrayList<ArrayList<Double>>();
	        ArrayList<ArrayList<Double>> percentiles = new ArrayList<ArrayList<Double>>();
	        ArrayList<ArrayList<String>> grades = new ArrayList<ArrayList<String>>();

	        for (String column : columns) {
	            avgValues.add(dao.getAvg(district, aItem, column));
	            percentiles.add(dao.getPercentile(district, aItem, column));
	            grades.add(dao.getGrades(district, aItem, column));
	        }

	        request.setAttribute("avgValues", avgValues);
	        request.setAttribute("percentiles", percentiles);
	        request.setAttribute("grades", grades);
	    }
}
