package com.analysis.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ADao {
	
	DataSource dataSource;
	
	public ADao() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<ADto> getAnalysisTableResult(String district, String aItem) {
		ArrayList<ADto> dtos = new ArrayList<ADto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			
			String query = "select from aItem = ? where district = ? ";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String districtName =rs.getString("district");
				String analysisItem  =rs.getString("analysisItem");
				double salePriceAvg = rs.getDouble("salePriceAvg");
				double jeonsePriceAvg = rs.getDouble("jeonsePriceAvg");
				double monthlyDepositAvg = rs.getDouble("monthlyDepositAvg");
				double monthlyAvg = rs.getDouble("monthlyAvg");
				double salePricePercentile = rs.getDouble("salePricePercentile");
				double jeonsePricePercentile = rs.getDouble("jeonsePricePercentile");
				double monthlyDepositPercentile = rs.getDouble("monthlyDepositPercentile");
				double monthlyPercentile = rs.getDouble("monthlyPercentile");
				String salePriceGrade =rs.getString("salePriceGrade");
				String jeonsePriceGrade =rs.getString("jeonsePriceGrade");
				String monthlyDepositGrade =rs.getString("monthlyDepositGrade");
				String monthlyGrade =rs.getString("monthlyGrade");
				
				ADto dto = new ADto(districtName, analysisItem, salePriceAvg, jeonsePriceAvg, monthlyDepositAvg, monthlyAvg, salePricePercentile, jeonsePricePercentile, monthlyDepositPercentile, 	monthlyPercentile, salePriceGrade, jeonsePriceGrade, monthlyDepositGrade,  monthlyGrade);
				
				dtos.add(dto);
			}
		}  catch(Exception e) {
			e.printStackTrace();
		} finally {
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	public ArrayList<Double> getAvg(String district, String aItem, String columnName) {
        ArrayList<Double> avgValues = new ArrayList<Double>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try { 
			conn = dataSource.getConnection();
			String query = "select avg("+columnName+")  FROM " + aItem + " WHERE district = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,  district);
			rs = pstmt.executeQuery();		
			
			while(rs.next()) {
                avgValues.add(rs.getDouble(1));

				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return avgValues;
	}
	
	public ArrayList<Double> getPercentile(String district, String aItem, String columnName) {
        ArrayList<Double> percentileValues = new ArrayList<Double>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try { 
			conn = dataSource.getConnection();
			String query = "select percentile("+columnName+")  FROM " + aItem + " WHERE district = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,  district);
			rs = pstmt.executeQuery();		
			
			while(rs.next()) {
				percentileValues.add(rs.getDouble(1));

				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return percentileValues;
	}
	
	public ArrayList<String> getGrades(String district, String aItem, String columnName) {
        ArrayList<String> gradeValues = new ArrayList<String>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try { 
			conn = dataSource.getConnection();
			String query = "select ("+columnName+")grade FROM " + aItem + " WHERE district = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,  district);
			rs = pstmt.executeQuery();		
			
			while(rs.next()) {
				gradeValues.add(rs.getString(1));

				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return gradeValues;
	}
}
