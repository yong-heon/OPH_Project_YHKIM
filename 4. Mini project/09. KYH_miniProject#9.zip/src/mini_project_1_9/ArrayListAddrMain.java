package mini_project_1_9;

import java.util.*;

public class ArrayListAddrMain {

	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		ArrayListAddr addrList = new ArrayListAddr();
		String name;
		System.out.println("# 데이터 2개를 입력합니다.");
		for(int i=0;i<2;++i) {
			addrList.addAddr(addrList.inputAddrData(null));
		}
		
		while(true) {
			printMenu();
			int selectMenu = scanner.nextInt();
			
			switch(selectMenu) {
			case 1: 
				addrList.addAddr(addrList.inputAddrData(null));
				break;
			case 2:
				System.out.println("검색할 이름을 입력하세요.");
				addrList.searchAddr(scanner.nextLine());
			case 3:
				System.out.println("수정할 연락처의 이름을 입력하세요.");
				name = scanner.nextLine();
				addrList.searchAddr(name);
				System.out.println("수정할 연락처를 새로 입력하세요.");
				addrList.editAddr(name, addrList.inputAddrData(null));
			case 4:
				System.out.println("삭제할 이름을 입력하세요.");
				addrList.deleteAddr(scanner.nextLine());
			case 5:
				addrList.printAll();
			case 6:
				addrList.saveFile();
			case 7:
				addrList.loadFile();
			case 8:
				System.out.println("프로그램을 종료합니다.");
				return;
				default:
					System.out.println("잘못된 메뉴 입니다. 다시 선택해주세요");
			}
		}
	}
	
	public static void printMenu() {
		System.out.println("주소관리 메뉴 ------------------");
		System.out.println(">> 1. 연락처 입력");
		System.out.println(">> 2. 연락처 검색");
		System.out.println(">> 3. 연락처 수정");
		System.out.println(">> 4. 연락처 삭제");
		System.out.println(">> 5. 연락처 전체 리스트 보기");
		System.out.println(">> 6. 연락처 파일 저장");
		System.out.println(">> 7. 연락처 파일 로드");
		System.out.println(">> 8. 프로그램 종료");
		System.out.println("----------------------------");
	}
}
