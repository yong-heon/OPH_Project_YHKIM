package miniProject01;

public class AddrMain {
	public static void main(String [] args) {
		Addr addr01 = new Addr ("최윤호", "010-1234-5678", "choi@gmail.com", "서울", "친구");
		
		addr01.printInfo();
		addr01.setGroup("가족");
		addr01.printInfo();
		
	}

}
