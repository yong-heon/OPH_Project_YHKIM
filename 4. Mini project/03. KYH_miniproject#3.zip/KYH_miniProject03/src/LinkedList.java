public class LinkedList {
	private ListNode head;
	
	public LinkedList() {
		head = null;
	}
	
	public void insertMiddleNode(ListNode pre, String data) {
		ListNode newNode = new ListNode(data);
		
		newNode.link = pre.link;
		pre.link = newNode;
	}
	
	public void insertLastNode(String data) {
		ListNode newNode = new ListNode(data);
		
		if(head ==null) {
			head = newNode;
		} else {
			ListNode lastNode = head; //lastNode는 head가 null이 아닐 때
			                                 			//head가 마지막 노드를 참조하기 위해서 만들어줌
			lastNode.link = newNode;
		}
	}
	
	public void deleteLastNode() {
		ListNode pre, temp;
		
		
		
	}
	
	public ListNode searchNode(String data) {
		ListNode temp = this.head;
		
		while(temp != null) {
			if(data.equals(temp.getData())) {
				return temp;
			} else {
				temp = temp.link;
			}
		}
		
		
		return temp;
	}
	
	public void reverseList() {
		ListNode next = this.head;
		ListNode current = null;
		ListNode pre = null;
		
		head = current;
	}
	
	public void printList() {
		ListNode temp = this.head;
		System.out.printf("L = (");
		while (temp !=null) {
			System.out.printf(temp.getData());
			temp = temp.link;
			if(temp != null) {
				System.out.printf(", ");
			}
		}
		System.out.println(")");
	}
}
