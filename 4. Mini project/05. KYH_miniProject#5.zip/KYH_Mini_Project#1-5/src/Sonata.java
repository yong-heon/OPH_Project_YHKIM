
public abstract class Sonata extends CarSpec{
	public int displacement;
	
	public Sonata(String color, String tire, int displacement, String handle) {
		super(color, tire, handle);
		this.displacement = displacement;
	}
	
	public  void color() {}
	public  void tire() {}
	public  void displacement() {}
	public  void handle() {}
	public  void getSpec() {}

}
