
public class CarSpec {
	

	public String color;
	public String tire;
	public String handle;
	
	public CarSpec(String color, String tire, String handle) {
		this.color = color;
		this.tire = tire;
		this.handle = handle;
	}

}
