
public class SonataHighGrade extends Sonata {
	public int tax;
	
	public SonataHighGrade(String color, String tire, int displacement, String handle) {
		super(color, tire, displacement, handle);
		
	}
	
	public void color() {
		color = "레드";
	}
	public void tire() {
		tire = "광폭타이어";
	}
	public void displacement() {
		displacement = 2500;
	}
	public void handle() {
		handle = "파워핸들";
	}
	public void getSpec() {
		if(displacement == 2500) {
			tax = 1500;
		} else if (displacement == 2000) {
		tax = 1000;
		} else {
			System.out.println("배기량을 올바르게 입력하세요");
			}
		}
}
