package Ch10_2_ExceptionHandling;

public class InputException extends Exception {
	public InputException() { }
	public InputException(String message) {
		super(message);
	}
	

}
