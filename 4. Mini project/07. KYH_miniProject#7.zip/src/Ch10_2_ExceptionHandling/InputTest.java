package Ch10_2_ExceptionHandling;

import java.util.Scanner;

public class InputTest {

	public static void main(String[] args) {

		try {
			String id;
			Scanner in = new Scanner(System.in);
			System.out.println("아이디를 입력해주세요.");
			id = in.nextLine();
			if (isString(id) == false) {
				throw new InputException ("아이디를 입력해 주십시오");
			} else {
				System.out.println("입력하신 아이디는 " + id + "입니다.");
			}
		} catch (InputException e) {
			String message = e.getMessage();
			System.out.println(message);
			System.out.println();
			e.printStackTrace();
		}
	}
	 public static boolean isString(String string) {	
		 if (string == null) {
			 return false;
		 }
		 for (int i = 0; i < string.length(); i++) {
			 char c = string.charAt(i);
			 if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c<= 'z') && !Character.isDigit(string.charAt(i))) {
				 return false;
			 } 
		 }
		 return true;
	 }

}
