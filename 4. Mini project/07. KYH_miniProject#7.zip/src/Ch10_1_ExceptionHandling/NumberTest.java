package Ch10_1_ExceptionHandling;

import java.util.Scanner;

public class NumberTest {
	public static void main(String[] args) {
		
		try {
			Scanner in = new Scanner(System.in);
			System.out.println("태어난 년도를 입력해주세요.");
			String num = in.nextLine();
			if (isNumber(num) == false) {
	            throw new InputException("입력하신 데이터는 숫자가 아닙니다.");
			} else {
				System.out.println("입력하신 년도는 : " + num + "입니다.");
			}
		} catch (InputException e) {
			String message = e.getMessage();
			System.out.println(message);
			System.out.println();
			e.printStackTrace();
			}
		}

	public static boolean isNumber(String num)  {
        boolean isNumeric = true;
        for (int i = 0; i < num.length(); i++) {
            if (!Character.isDigit(num.charAt(i))) {
                isNumeric = false;
                break; 					//문자가 한 번이라도 있으면 바로 걸리게 해놓음
            }
        }
        return isNumeric;
		
//		try {Integer.parseInt(num);	
//		return true;
//	} catch (NumberFormatException exception) {
//		return false;
//		}
	}
}
