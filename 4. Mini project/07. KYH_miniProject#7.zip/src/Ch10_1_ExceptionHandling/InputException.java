package Ch10_1_ExceptionHandling;

public class InputException extends Exception {
	public InputException() { }
	public InputException(String message) {
		super(message);
	}
}
