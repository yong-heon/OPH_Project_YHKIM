package mini_project_1_8_01;

import java.util.*;

public class ArrayListAddr {
	Scanner in = new Scanner(System.in);
	List<Addr> addr = new ArrayList<Addr>();
		
	public Addr inputAddrData(String groupName) {
		Addr addrGroup;
		System.out.println("이름 : ");
		String name = in.nextLine();
		System.out.println("전화번호 : ");
		String phnNum = in.nextLine();
		System.out.println("이메일 : ");
		String email = in.nextLine();
		System.out.println("주소 : ");
		String addr = in.nextLine();
		System.out.println("생일 : ");
		String birth = in.nextLine();
		if(isCompany(groupName)==true) {
			String group = "회사";
			System.out.println("회사이름 : ");
			String company = in.nextLine();
			System.out.println("부서이름 : ");
			String department = in.nextLine();
			System.out.println("직위 : ");
			String position = in.nextLine();
			addrGroup = new CompanyAddr(name,phnNum,email,addr,birth,group,company,department,position);
		}else{
			String group = "거래처";
			System.out.println("거래처이름 : ");
			String client = in.nextLine();
			System.out.println("거래품목 : ");
			String trnsactionItem = in.nextLine();
			System.out.println("직위 : ");
			String position = in.nextLine();
			addrGroup =  new CustomerAddr(name,phnNum,email,addr,birth,group,client,trnsactionItem,position);
		}
		return addrGroup;
	}
	public boolean isCompany(String groupName) {
		if(groupName==null) {	
			System.out.println("그룹(회사/거래처) : ");
			groupName = in.nextLine();
		}
		while(groupName.contentEquals("회사")==false && groupName.contentEquals("거래처")==false) {
			System.out.println("잘못된 그룹입니다. 다시 입력해주세요.\n그룹(회사/거래처) : ");
			groupName = in.nextLine();
		}
		if(groupName.contentEquals("회사")) {return true;}
		
		return false;
	}
	public void addAddr(Addr Addr) {
		addr.add(Addr);	
		int i;
		i = addr.size();
		System.out.println(">>> 데이터가 저장되었습니다." + i);
	}
	public void printAddr(Addr Addr) {
		System.out.println("---------------------------------");
		System.out.println("이름 : "+Addr.getName());
		System.out.println("전화번호 : "+Addr.getPhnNum());
		System.out.println("이메일 : "+Addr.getEmail());
		System.out.println("주소 : "+Addr.getAddr());
		System.out.println("생일 : "+Addr.getBirth());
		System.out.println("그룹 : "+Addr.getGroup());
		if(isCompany(Addr.getGroup())==true) {
			if(Addr instanceof CompanyAddr) {
				CompanyAddr company = (CompanyAddr)Addr;
				System.out.println("회사 이름 : "+company.getCompanyName());
				System.out.println("부서 이름 : "+company.getDepartment());
				System.out.println("직위 : "+company.getPosition());
			}
		}else{
			if(Addr instanceof CustomerAddr) {
				CustomerAddr customer = (CustomerAddr)Addr;
				System.out.println("거래처 이름 : "+customer.getClientName());
				System.out.println("품목 이름 : "+customer.getTrnsactionItem());
				System.out.println("직위 : "+customer.getPosition());
			}
		}
		System.out.println("---------------------------------");
	}
	public void printAll() {
		for(int i = 0; i<addr.size(); i++) {
			printAddr(addr.get(i));
		}
	}
	public void searchAddr(String name) {
		for (int j = 0; j < addr.size(); j++) {
			if (addr.get(j).getName().contentEquals(name)) {
				printAddr(addr.get(j));
				return;
			} 
			System.out.println("검색 결과가 없습니다. 올바른 값을 입력해 주세요.");
		} 
	}
	public void deleteAddr(String name) {
		for(int i = 0; i < addr.size(); i ++) {
			if(addr.get(i).getName().contentEquals(name)) {
				addr.remove(i);
				return;
			}
		}
	}
	public void editAddr(String name, Addr newAddr) {
		for(int i = 0; i < addr.size(); i ++) {
			if(addr.get(i).getName().contentEquals(name)) {
				addr.set(i, newAddr);
				return;
				
			}
		}
	}
}
