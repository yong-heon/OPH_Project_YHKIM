
public interface IFunction {
	String CALLSENDNRECIEVE_POSSIBLE = "가능";
	String CALLSENDNRECIEVE_IMPOSSIBLE = "불가능";
	String NETWORKGENERATION_3G = "3G";
	String NETWORKGENERATION_4G = "4G";
	String NETWORKGENERATION_5G = "5G";
	String TVREMOTECONTROL_POSSIBLE = "탑재";
	String TVREMOTECONTROL_IMPOSSIBLE = "미탑재";
	
	void callSendnRecieve();
	void networkGeneration();
	void tvRemoteControl();
}
