
public class BPhone implements IFunction {
	
	public void callSendnRecieve() {
		System.out.println("전화 " + CALLSENDNRECIEVE_POSSIBLE + "합니다.");
	}
	public void networkGeneration() {
		System.out.println("접속속도는 "  + NETWORKGENERATION_5G + "입니다.");
	}
	public void tvRemoteControl() {
		System.out.println(TVREMOTECONTROL_POSSIBLE + "되어 있습니다.");
	}

}
