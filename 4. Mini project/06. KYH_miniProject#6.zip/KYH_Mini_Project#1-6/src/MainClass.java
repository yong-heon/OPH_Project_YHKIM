
public class MainClass {
	public static void main(String [] args) {
		IFunction aPhone;
		aPhone = new APhone();
		
		IFunction bPhone;
		bPhone = new BPhone();
		
		IFunction cPhone;
		cPhone = new CPhone();
		
		System.out.println("A Phone");
		aPhone.callSendnRecieve();
		aPhone.networkGeneration();
		aPhone.tvRemoteControl();
		System.out.println("=======================");
		System.out.println("B Phone");
		bPhone.callSendnRecieve();
		bPhone.networkGeneration();
		bPhone.tvRemoteControl();
		System.out.println("=======================");
		System.out.println("C Phone");
		cPhone.callSendnRecieve();
		cPhone.networkGeneration();
		cPhone.tvRemoteControl();
		System.out.println("=======================");

	}

}
