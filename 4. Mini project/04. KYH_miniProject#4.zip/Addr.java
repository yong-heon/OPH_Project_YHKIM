

public class Addr {
	private String name;
	private String phoneNum;
	private String emailId;
	private String address;
	private String group;
	
	public Addr (String name, String phoneNum, String emailId, String address, String group) {
		this.name = name;
		this.phoneNum = phoneNum;
		this.emailId = emailId;
		this.address = address;
		this.group = group;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
	
	void printInfo() {
		System.out.print("\n이름 : " + name + "\n전화번호 : " + phoneNum + 
				"\n이메일 : " + emailId + "\n주소 : " + address + "\n그룹 : " + group);
		System.out.print("\n---------------------------------------------");
		
	}	
}
