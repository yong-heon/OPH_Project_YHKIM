 import java.util.Scanner;

public class SmartPhone {
   Addr[] addrs = new Addr[10];

   int n = 0;
   
   Addr inputAddData() {
      Scanner in = new Scanner(System.in);
      System.out.print("\n이름 : ");
      String name = in.nextLine();
      System.out.print("전화번호 : ");
      String phoneNum = in.nextLine();
      
      System.out.print("이메일 : ");
      String emailId = in.nextLine();
      System.out.print("주소 : ");
      String address = in.nextLine();
      System.out.print("그룹(친구/가족) : ");
      String group = in.nextLine();
      
      Addr addAddrs = new Addr(name, phoneNum, emailId, address, group);
      return addAddrs;
   }
   void  addAddr(Addr addAddrs) {
      addrs[n] =addAddrs;
      n++;
      System.out.print(">>> 데이터가 저장되었습니다. (" + (n) + ")");
   }
   void printAddr(Addr addAddrs) {
      System.out.println("이름 : " + addrs[n].getName());
      System.out.println("전화번호 : " +addrs[n].getPhoneNum());
      System.out.println("이메일 : " + addrs[n].getEmailId());
      System.out.println("주소 : " + addrs[n].getAddress());
      System.out.println("그룹(친구/가족) : " + addrs[n].getGroup());
   }

   void printAllAddr() {
      System.out.println("---모든 연락처 출력---");
      for(int i = 0; i<n; i++) {
         addrs[i].printInfo();
      }
   }
   
   void searchAddr(String searchName) {
	   for (int i = 0; i<n; i++) {
		   if(searchName.contentEquals(addrs[i].getName())) {
			   addrs[i].printInfo();
			   break;		   	   
		   }
			   System.out.println("\n입력한 이름의 연락처를 찾을 수 없습니다.");
		 }
	 }
   void deleteAddr(String deleteName) {
	   int targetN = -1; // i가 0부터 시작하니까 targetN 값은 -1로 초기화 해야됨
	   for(int i = 0; i<n; i++) {
		   if(deleteName.contentEquals(addrs[i].getName())) {
			   targetN = i;
		   }
	   }
			   if(targetN != -1) {
				   for(int i= targetN; i<n-1; i ++) {
					   addrs[i].setName(addrs[i+1].getName());
					   addrs[i].setPhoneNum(addrs[i+1].getPhoneNum());
					   addrs[i].setEmailId(addrs[i+1].getEmailId());
					   addrs[i].setAddress(addrs[i+1].getAddress());
					   addrs[i].setGroup(addrs[i+1].getGroup());
				   }
				   n--; 
			   }
			   System.out.println("연락처 삭제를 완료하였습니다.");	
	   }
   void editAddr(String editName, Addr newAddr) {
	      Scanner in = new Scanner(System.in);

	   for(int i = 0; i<n; i++) {
		   if(editName.contentEquals(addrs[i].getName())) {
			   System.out.println("수정하려는 이름을 입력해주세요 : ");
			   addrs[i].setName(in.nextLine());
			   System.out.println("수정하려는 전화번호를 입력해주세요 : ");
			   addrs[i].setPhoneNum(in.nextLine());
			   System.out.println("수정하려는 이메일을 입력해주세요 : ");
			   addrs[i].setEmailId(in.nextLine());
			   System.out.println("수정하려는 주소를 입력해주세요 : ");
			   addrs[i].setAddress(in.nextLine());
			   System.out.println("수정하려는 그룹을 입력해주세요 : ");
			   addrs[i].setGroup(in.nextLine());
		   }
		   addrs[i] = new Addr(addrs[i].getName(), addrs[i].getPhoneNum(), addrs[i].getEmailId(), addrs[i].getAddress(), addrs[i].getGroup());
	   }
	   System.out.println("수정이 완료되었습니다.");
   }
}

 