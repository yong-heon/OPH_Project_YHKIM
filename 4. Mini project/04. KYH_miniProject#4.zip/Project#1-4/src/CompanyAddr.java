
public class CompanyAddr extends Addr {
	private String comName;
	private String unitName;
	private String position;

	public CompanyAddr(String name, String phoneNum, String emailId, String address, String group, String comName, String unitName, String position) {
		super(name, phoneNum, emailId, address, group);
		this.comName = comName;
		this.unitName = unitName;
		this.position = position;
	}

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	@Override
	void printInfo() {
		System.out.printf("\n이름 : " + getName() + "\n전화번호 : " + getPhoneNum() + 
				"\n이메일 : " + getEmailId() + "\n주소 : " + getAddress() + "\n그룹 : " + getGroup(), "\n회사이름 : " + comName + 
				"\n부서이름 : " + unitName + "\n직급 : " + position);
		System.out.print("\n---------------------------------------------");
	}

}
