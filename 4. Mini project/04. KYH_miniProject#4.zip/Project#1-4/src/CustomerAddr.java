
public class CustomerAddr extends Addr {
	private String custName;
	private String field;
	private String position;
	
	public CustomerAddr(String name, String phoneNum, String emailId, String address, String group, String custName, String field, String position) {
		super(name, phoneNum, emailId, address, group);
		this.custName = custName;
		this.field = field;
		this.position = position;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	@Override
	void printInfo() {
		System.out.printf("\n이름 : " + getName() + "\n전화번호 : " + getPhoneNum() + 
				"\n이메일 : " + getEmailId() + "\n주소 : " + getAddress() + "\n그룹 : " + getGroup(), "\n거래처이름 : " + custName + 
				"\n품목이름 : " + field + "\n직급 : " + position);
		System.out.print("\n---------------------------------------------");
	}


	
	

}
